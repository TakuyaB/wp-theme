<div id="sidebar">
    <ul>
        <?php dynamic_sidebar(); ?>
    </ul>
</div><!-- sidebarここまで -->
