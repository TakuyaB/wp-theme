<div id="footer">
    <p>Copyright &copy; <?php bloginfo( 'name' ); ?> All right Reserved.</p>
</div>
<?php wp_footer(); ?>
<a href="#top" class="page_top">▲</a>
</body>
</html>